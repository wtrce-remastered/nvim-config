return {
    'mfussenegger/nvim-jdtls',
    ft = 'java'
}
