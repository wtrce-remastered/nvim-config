return {
    'numToStr/Comment.nvim',
    config = function ()
        require('Comment').setup({
             sticky = true
        })
    end
}
