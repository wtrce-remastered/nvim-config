# Setup on arch
curl -sL https://raw.githubusercontent.com/wtrce-remastered/nvim-config/master/install/arch-install.sh | bash
